package lessonEight;

public interface DoAction {
    void run();
    void jump();
}
