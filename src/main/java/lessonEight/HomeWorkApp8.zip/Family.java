package lessonEight;

public interface Family {
    boolean run(int distance);
    boolean jump(int height);
}
