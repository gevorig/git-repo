package lessonEight;

public interface Barrier {
    boolean come(Family family);
}
